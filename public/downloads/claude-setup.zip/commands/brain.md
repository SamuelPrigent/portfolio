# Brain — Brainstorm créatif & UX/UI

## Contexte de la demande

$ARGUMENTS

## Instructions

**IMPORTANT : Ne code pas. On est en mode brainstorm pur.** L'objectif est d'explorer les possibilités, challenger les idées et proposer les meilleures options UX/UI avant toute implémentation.

### Phase 1 — Scan rapide du projet

- Fais un scan léger et ciblé du projet : structure des dossiers, stack technique, composants UI existants, design system en place, routes principales.
- Ne lis que le strict minimum nécessaire pour comprendre le contexte (config, layout principal, composants clés liés à la demande).
- Identifie les patterns UX/UI déjà utilisés dans l'app (navigation, formulaires, modales, toasts, animations, etc.).
- Note la stack front-end (framework, librairie UI, CSS, state management) pour adapter tes propositions.

### Phase 2 — Brainstorm : exploration des possibilités

Génère au minimum **3 propositions distinctes** qui répondent à la demande, en variant les approches. Pour chaque proposition :

#### Proposition N — [Nom court et évocateur]

- **Concept** : Description claire de l'approche en 2-3 phrases.
- **UX/UI** : Comment ça se manifeste visuellement et interactivement pour l'utilisateur. Décris le flow utilisateur étape par étape.
- **Points forts** : Ce que cette approche apporte de mieux.
- **Points faibles** : Les compromis ou limites.
- **Complexité** : 🟢 Simple | 🟡 Modérée | 🔴 Complexe — avec une estimation du nombre de fichiers/composants impactés.
- **Inspiration** : Si applicable, cite des apps/produits connus qui utilisent cette approche.

### Phase 3 — Analyse comparative

Présente un tableau de synthèse :

| Critère              | Proposition 1 | Proposition 2 | Proposition 3 |
| -------------------- | ------------- | ------------- | ------------- |
| UX/UI Qualité        |               |               |               |
| Complexité technique |               |               |               |
| Cohérence avec l'app |               |               |               |
| Standards du marché  |               |               |               |
| Accessibilité        |               |               |               |
| Performance          |               |               |               |

Puis donne ton analyse :

- **🏆 Ce qui se fait le plus souvent** : Quelle approche est le standard du marché ? Cite des exemples concrets d'apps connues.
- **🎯 Ce qui correspond le mieux à ton app** : En se basant sur les patterns existants dans le code, le design system en place, et la stack technique, quelle proposition s'intègre le plus naturellement ?
- **⭐ Ma recommandation** : Quelle proposition je te recommande et pourquoi. Sois opinionated — tranche clairement en expliquant ton raisonnement.

### Phase 4 — Idées bonus & provocations

Challenge la demande elle-même :

- Y a-t-il une approche à laquelle l'utilisateur n'a probablement pas pensé ?
- Peut-on combiner le meilleur de plusieurs propositions ?
- Existe-t-il une solution plus simple qui résoudrait 80% du besoin avec 20% de l'effort ?
- Un quick win immédiat avant d'implémenter la solution complète ?

### Phase 5 — Questions avant de passer à l'action

- Pose tes questions pour affiner la direction choisie.
- Propose des variantes si certains aspects de la demande sont ambigus.
- Si tu détectes une incohérence ou un risque UX, signale-le.

---

**Format de réponse attendu** : Utilise des emojis pour les titres de sections, des tableaux pour les comparaisons, et des descriptions visuelles claires. Sois concis mais percutant — chaque mot doit compter. Privilégie les descriptions qui permettent de _visualiser_ le résultat final.

**Rappel** : On ne code rien. On explore, on compare, on choisit. L'implémentation viendra après validation de la direction.
