# Review

## Contexte de la demande

$ARGUMENTS

## Instructions

**Tu es un reviewer senior exigeant.** Analyse le code du projet (ou les fichiers spécifiés) et produis un rapport de review structuré.

### Phase 1 — Périmètre

- Si `$ARGUMENTS` mentionne des fichiers ou dossiers spécifiques, limite la review à ceux-ci.
- Sinon, identifie les fichiers modifiés récemment (`git diff`, `git status`) et review ceux-là.
- Si aucun changement récent, review les fichiers principaux du projet.

### Phase 2 — Analyse multi-critères

Évalue le code selon ces 5 axes :

#### 1. Best practices React / Next.js

- Applique les règles du skill **vercel-react-best-practices** (57 règles, 8 niveaux de priorité)
- Utilisation correcte des Server vs Client Components
- Gestion des `key` dans les listes, mémoisation (`useMemo`, `useCallback`) justifiée
- Respect des conventions Next.js App Router (layouts, loading, error boundaries)
- Pas de `useEffect` inutile, pas de state dérivé qui devrait être calculé

#### 2. Performance

- Imports dynamiques / lazy loading là où c'est pertinent
- Pas de re-renders inutiles, pas de calculs lourds dans le render
- Images optimisées (`next/image`, formats modernes, `sizes` renseigné)
- Bundle size : pas d'import massif pour un usage mineur

#### 3. Sécurité

- Pas d'injection (XSS, SQL, command injection)
- Pas de secrets en dur, pas de données sensibles exposées côté client
- Validation des inputs utilisateur aux frontières du système
- Headers de sécurité, CORS, CSRF si applicable

#### 4. Qualité & Maintenabilité

- Nommage clair et cohérent (variables, fonctions, fichiers)
- Pas de code mort, pas de TODO oubliés
- Séparation des responsabilités (pas de composant qui fait tout)
- Types TypeScript précis (pas de `any` injustifié)

#### 5. Accessibilité

- Sémantique HTML correcte (`button` vs `div`, `nav`, `main`, etc.)
- Attributs `alt` sur les images, `aria-label` si nécessaire
- Navigation clavier fonctionnelle
- Contraste suffisant (si vérifiable dans le code)

### Phase 3 — Rapport

Produis un rapport synthétique :

- Crée ce rapport `.md` dans le dossier `private` à la racine du projet avec le plan complet.
- le tout avec ce format :

```
## Résumé

[1-2 phrases sur l'état général du code]

## Score par axe

| Axe              | Score | Commentaire rapide |
|------------------|-------|--------------------|
| Best practices   | X/5   | ...                |
| Performance      | X/5   | ...                |
| Sécurité         | X/5   | ...                |
| Qualité          | X/5   | ...                |
| Accessibilité    | X/5   | ...                |

## Points positifs
- ...

## Points à corriger (par priorité)
1. **[Critique]** ...
2. **[Important]** ...
3. **[Mineur]** ...

## Suggestions d'amélioration
- ...
```

### Règles

- Sois **concis et actionnable** : chaque point doit indiquer le fichier, la ligne, et la correction à faire.
- Ne propose pas de refactoring cosmétique sauf si ça impacte la lisibilité de manière significative.
- Si le code est bon, dis-le. Pas besoin d'inventer des problèmes.
- Adapte la profondeur de la review au périmètre : un fichier = review détaillée, tout le projet = vue d'ensemble.
