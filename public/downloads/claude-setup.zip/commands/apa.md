# Analyse Plan Ask

## Contexte de la demande

$ARGUMENTS

## Instructions

**IMPORTANT : Ne code pas tout de suite.** On entre dans une phase d'analyse pure.

### Phase 1 — Analyse du code existant

- Parcours toutes les couches du projet (routes, controllers, services, models, middlewares, utils, configs, tests, etc.) pour comprendre l'architecture existante.
- Identifie précisément les couches et fichiers qui seront impactés par cette feature.
- Vérifie ce qui pourrait casser en implémentant cette feature : dépendances entre modules, effets de bord, contrats d'API, validations, types, tests existants.
- Liste les éléments dont il faudra tenir compte pour ne rien casser.

### Phase 2 — Plan d'action

Présente un plan structuré et clair avec :
- Les fichiers à modifier (avec le chemin complet)
- Les fichiers à créer si nécessaire
- Pour chaque fichier : les actions précises à effectuer
- L'ordre d'implémentation recommandé
- Les risques identifiés et les précautions à prendre

### Phase 3 — Questions et clarifications

Après l'analyse et la lecture du code, pose-moi toutes les questions en suspens :
- Sur les zones d'ombre dans ma demande
- Sur les cas particuliers que tu as identifiés pendant l'analyse
- Si je n'ai pas été précis sur un aspect, demande-moi comment je veux le résoudre
- Si tu détectes une erreur ou incohérence dans ma demande, signale-le et propose des alternatives
- **Évite les suppositions** : en cas de doute, pose la question plutôt que de deviner

On ne passera à l'implémentation qu'une fois que toutes les questions seront résolues et le plan validé.
